#!/usr/bin/env perl

package FlashTestApp;
use Catalyst qw/Session Session::Store::Dummy Session::State::Cookie/;

use strict;
use warnings;

__PACKAGE__->setup;

__PACKAGE__;

