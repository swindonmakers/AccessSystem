package Form::Multiple;

use Moose;
extends ('Form::Person', 'Form::Address');


no Moose;
1;
