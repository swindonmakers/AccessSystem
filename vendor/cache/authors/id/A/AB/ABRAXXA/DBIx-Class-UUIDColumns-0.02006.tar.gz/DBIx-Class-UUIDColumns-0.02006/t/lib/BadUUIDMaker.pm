package BadUUIDMaker;

use strict;
use warnings;

sub as_string {
    return '12345678-1234-2345-3456-123456789090';
};

1;
__END__