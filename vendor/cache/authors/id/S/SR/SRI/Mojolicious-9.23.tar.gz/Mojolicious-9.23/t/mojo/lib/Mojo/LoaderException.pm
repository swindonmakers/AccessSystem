package Mojo::LoaderException;

use Mojo::Base -base;

sub new { }

foo {

1;
