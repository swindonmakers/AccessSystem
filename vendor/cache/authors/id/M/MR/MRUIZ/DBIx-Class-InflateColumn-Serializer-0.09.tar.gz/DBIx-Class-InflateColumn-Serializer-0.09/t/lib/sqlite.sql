CREATE TABLE testtable (
  testtable_id INTEGER PRIMARY KEY NOT NULL,
  serial1 VARCHAR(100),
  serial2 VARCHAR(100),
  serial3 VARCHAR(10)
);

