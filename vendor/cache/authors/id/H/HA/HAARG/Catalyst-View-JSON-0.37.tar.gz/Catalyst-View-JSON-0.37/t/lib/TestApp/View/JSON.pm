package TestApp::View::JSON;
use base qw( Catalyst::View::JSON );

1;
