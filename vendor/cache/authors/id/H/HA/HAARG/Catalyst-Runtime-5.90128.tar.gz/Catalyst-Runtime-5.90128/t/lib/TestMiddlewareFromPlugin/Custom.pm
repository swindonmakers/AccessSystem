package TestMiddlewareFromPlugin::Custom;

use strict;
use warnings;

use parent qw/Plack::Middleware::Static/;

1;
