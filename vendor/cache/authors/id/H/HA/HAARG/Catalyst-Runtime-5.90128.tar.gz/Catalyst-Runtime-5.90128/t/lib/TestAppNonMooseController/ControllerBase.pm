package TestAppNonMooseController::ControllerBase;
use base qw/Catalyst::Controller/;

1;

