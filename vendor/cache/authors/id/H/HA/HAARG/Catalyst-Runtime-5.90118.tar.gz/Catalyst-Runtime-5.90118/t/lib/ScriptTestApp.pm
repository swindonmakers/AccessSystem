package ScriptTestApp;
use Moose;

extends 'Catalyst';

__PACKAGE__->setup;
1;

