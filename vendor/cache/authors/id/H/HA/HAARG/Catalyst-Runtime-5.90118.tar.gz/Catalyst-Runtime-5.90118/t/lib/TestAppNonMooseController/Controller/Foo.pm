package TestAppNonMooseController::Controller::Foo;
use base qw/TestAppNonMooseController::ControllerBase/;

1;

