package ScriptTestApp::Script::CompileTest;
use Moose;
use namespace::clean -except => [ 'meta' ];

die("Does not compile");

1;
