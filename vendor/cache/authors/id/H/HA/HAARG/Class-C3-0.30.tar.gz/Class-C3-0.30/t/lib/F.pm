package t::lib::F;
use Class::C3;
use base ('t::lib::C', 't::lib::D');
1;
