###############################################################################
# Purpose : Selection of FILE I/O policy
# Author  : John Alden
# Created : March 2005
# CVS     : $Id: Config.pm,v 1.2 2005/03/31 17:28:26 sysadm Exp $
###############################################################################
# This is the default configuration - please update as necessary
###############################################################################

package File::Policy::Config;

use constant IMPLEMENTATION => 'Default';

1;

