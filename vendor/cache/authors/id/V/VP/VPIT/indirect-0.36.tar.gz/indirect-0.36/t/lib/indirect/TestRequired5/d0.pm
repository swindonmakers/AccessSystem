package indirect::TestRequired5::d0;
new X;
1;
