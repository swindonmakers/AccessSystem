Catalyst-Controller-AutoAssets
==============================

Automatic asset serving via sha1-based URLs

See [Catalyst::Controller::AutoAssets](https://metacpan.org/module/Catalyst::Controller::AutoAssets) for documentation.

