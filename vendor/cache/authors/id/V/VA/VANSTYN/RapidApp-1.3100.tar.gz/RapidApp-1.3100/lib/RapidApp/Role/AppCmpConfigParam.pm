package RapidApp::Role::AppCmpConfigParam;

use Moose::Role;

1;