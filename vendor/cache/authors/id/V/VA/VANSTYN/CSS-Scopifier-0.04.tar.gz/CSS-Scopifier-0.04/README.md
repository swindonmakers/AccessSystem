CSS-Scopifier
=============

Prepends CSS rules to apply scope

[![Coverage Status](https://coveralls.io/repos/vanstyn/CSS-Scopifier/badge.png?branch=master)](https://coveralls.io/r/vanstyn/CSS-Scopifier?branch=master)
