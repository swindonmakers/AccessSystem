package # Hide from PAUSE
     TestApp::Controller::Assets;
use parent 'Catalyst::Controller::AutoAssets';

1;
