# RapidApp

RapidApp is an open-source application framework that is currently under development for quickly building dynamic Web 2.0/AJAX interfaces for various data models. It is based on the following open-source technologies:

- Perl
- Catalyst
- ExtJS
- DBIx::Class
- Template::Toolkit

This is a development release and the API is not yet complete and likely to change. Documentation is still in progress.


Please see the RapidApp homepage for more information: **[www.rapidapp.info](http://www.rapidapp.info)**

