package RapidApp::Column;
use strict;
use warnings;

die "RapidApp::Column was renamed/moved to RapidApp::Module::DatStor::Column";


1;
