package A::Result;

use DBIx::Class::Candy::Exports;

sub giant_robot { 1 }

export_methods ['giant_robot'];

1;
