package A::Schema::Result;

use base 'DBIx::Class::Core';

1;
