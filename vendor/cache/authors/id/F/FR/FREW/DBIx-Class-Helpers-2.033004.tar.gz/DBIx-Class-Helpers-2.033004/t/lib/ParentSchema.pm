package ParentSchema;
use parent 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces();

'kitten eater';
