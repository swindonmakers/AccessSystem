package VerifySchema::ResultSet::B;

use DBIx::Class::Candy::ResultSet;

use base 'Herp';

1;
