package RS;

use parent 'ParentRS';

__PACKAGE__->load_components('Helper::ResultSet::Random');

1;
