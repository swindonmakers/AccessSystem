package VerifySchema::ResultSet::A;

use DBIx::Class::Candy::ResultSet;

use base 'Herp';

1;
