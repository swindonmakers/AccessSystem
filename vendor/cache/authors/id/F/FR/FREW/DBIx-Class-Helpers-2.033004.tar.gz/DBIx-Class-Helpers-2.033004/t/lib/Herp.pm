package Herp;

sub noise {}

1;
