package TestSchema::ResultSet::HasAccessor;
use strict;
use warnings;

use parent 'TestSchema::ResultSet';

__PACKAGE__->load_components();

1;
