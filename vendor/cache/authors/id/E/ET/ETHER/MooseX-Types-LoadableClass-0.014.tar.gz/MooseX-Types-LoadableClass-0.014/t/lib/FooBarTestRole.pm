package FooBarTestRole;
use Moose::Role;
1;
