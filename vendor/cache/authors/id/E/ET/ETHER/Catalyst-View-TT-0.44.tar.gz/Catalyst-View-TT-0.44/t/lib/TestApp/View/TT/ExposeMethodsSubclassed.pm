package TestApp::View::TT::ExposeMethodsSubclassed;

use Moose;
extends 'TestApp::View::TT::ExposeMethods';

1;
