package Moose::Exception::Legacy;
our $VERSION = '2.1605';

use Moose;
extends 'Moose::Exception';

1;
