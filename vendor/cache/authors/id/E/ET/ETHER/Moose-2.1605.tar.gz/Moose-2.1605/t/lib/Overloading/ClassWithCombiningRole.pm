package Overloading::ClassWithCombiningRole;

use Moose;

with 'Overloading::CombiningRole';

1;
