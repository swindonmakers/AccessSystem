package SomeClass;

use Moose;
use namespace::autoclean;

with 'Role';

1;
