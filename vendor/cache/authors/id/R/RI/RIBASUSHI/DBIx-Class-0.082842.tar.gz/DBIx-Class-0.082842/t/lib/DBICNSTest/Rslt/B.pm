package DBICNSTest::Rslt::B;

use warnings;
use strict;

use base qw/DBIx::Class::Core/;
__PACKAGE__->table('b');
__PACKAGE__->add_columns('b');
1;
