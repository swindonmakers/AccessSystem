#   belongs to t/05components.t
package # hide from PAUSE
    DBICTest::ForeignComponent::TestComp;
use warnings;
use strict;

sub foreign_test_method { 1 }

1;
