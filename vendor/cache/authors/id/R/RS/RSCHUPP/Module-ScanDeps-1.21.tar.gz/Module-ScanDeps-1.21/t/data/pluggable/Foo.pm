package Foo;

use Module::Pluggable;

1;
