use strict;
use lib 'lib';
use IO::All;

io('xxx');
