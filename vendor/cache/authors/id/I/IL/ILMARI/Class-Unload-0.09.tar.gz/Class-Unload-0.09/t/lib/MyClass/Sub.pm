package # Hide from the CPAN indexer
    MyClass::Sub;

our $VERSION = '0.01';

1;
