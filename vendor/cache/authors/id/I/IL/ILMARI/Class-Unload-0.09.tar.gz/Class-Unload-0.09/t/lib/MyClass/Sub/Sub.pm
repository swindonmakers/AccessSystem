package # Hide from the CPAN indexer
    MyClass::Sub::Sub;

our $VERSION = '0.01';

1;
