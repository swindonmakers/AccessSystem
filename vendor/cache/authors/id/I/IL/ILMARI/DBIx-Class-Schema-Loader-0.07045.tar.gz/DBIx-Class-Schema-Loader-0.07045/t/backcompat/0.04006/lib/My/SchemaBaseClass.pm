package My::SchemaBaseClass;
use strict;
use warnings;

use base 'DBIx::Class::Schema';

1;
