package TestLoaderSubclass;

use strict;
use warnings;
use base qw/DBIx::Class::Schema::Loader::DBI::SQLite/;

1;
