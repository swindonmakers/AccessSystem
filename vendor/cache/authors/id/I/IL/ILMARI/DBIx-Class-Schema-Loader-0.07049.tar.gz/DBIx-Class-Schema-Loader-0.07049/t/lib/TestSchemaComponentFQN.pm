package TestSchemaComponentFQN;
use strict;
use warnings;

sub testschemacomponent_fqn { 'TestSchemaComponentFQN works' }

1;
