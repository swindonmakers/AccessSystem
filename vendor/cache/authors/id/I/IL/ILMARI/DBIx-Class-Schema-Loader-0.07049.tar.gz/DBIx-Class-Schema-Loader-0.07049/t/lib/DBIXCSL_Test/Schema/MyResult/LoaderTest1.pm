package DBIXCSL_Test::Schema::MyResult::LoaderTest1;
use strict;
use warnings;

sub loader_test1_classmeth { 'all is well' }

1;
